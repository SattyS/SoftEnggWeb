Send email in PHP by Gmail
==============================

For the send email in PHP by Gmail id, I've used phpmailer class.
see the full code in zip file.
php_openssl must be commented in the php.ini file.


- Amit

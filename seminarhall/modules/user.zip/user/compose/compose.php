<html>
	<head>
    	<title>
        	New Meeting
        </title>
        <link rel="stylesheet" href="../../../css/style.css" />
    </head>
    <body>
    
    <div id="header">
   		 <?php include("../../common/toplinks.html"); ?>
    	<img src="../../../images/logo.gif" />
    </div>
    <hr color="#666666" size="1px" />
    
    <div id="bodymainmiddlePan">
    	<?php
			include("../../accounts/logclass.php");
			$obj = new Logclass;
			
			$result = $obj -> isLoggedIn();
			
			if( $result )
			{
				include("inputform.php");
			}
			else
			{
				echo "Please login <a href='../../../index.php'>here</a>";
			}
		?>
	</div>
    
    </body>
</html>
<?php

	echo $_COOKIE["locuser"];
	
	echo "<pre>";
	print_r($_COOKIE);
	echo "</pre>";
?>
<html>
	<head>
    	<title>
        	Members Area
        </title>
        <link href="../../../css/style.css" rel="stylesheet" type="text/css" />
        
    </head>
    <body>
    
    <div id="header">
    	   <ul>
        
    <li><a href="../../../getmeout.php">Logout</a></li>
    <li><a href="../../chat/experts.php">Chat</a></li>
    <li><a href="../Archives/results.php">Archive</a></li>
    <li><a href="../inbox/inbox.php">Messages</a></li>
    <li><a href="../compose/compose.php">New</a></li> 
    <li><a href="members.php">Menu</a></li>      
    
</ul>
    	<marquee width="200 direction="right" behavior="alternate"><img src="../../../images/logo.gif"  /> </marquee>
    </div>
    <hr color="#666666" size="1px" />
    
    <div id="bodymainmiddlePan">
  <div id="bodymiddlePan">
 
  <div id="scroller">
    
    <div id="sidebar">
	 <ul>
	  <li>
	   <h2><a href="#">Past meetings</a></h2>
	<marquee scrollamount="1" scrolldelay="10" direction="up" height="300" style="font-family: Verdana; font-size: 8pt">
  				<ul>
					<li><a href="#">CEGLUG meet - WHat;s neW in LINux ??</a></li>
					
					<li><a href="#">IBM -TGMC meet</a></li>
					<li><a href="#">WEBsite DEVELOPment a recap</a></li>
					<li><a href="#">ooad,lecture</a></li>
					<li><a href="#">5th sem class comittee outcomes</a></li>
					<li><a href="#">Insight brainstorm- a review</a></li>
				</ul>
</marquee>
   </div>
   <h2 class="vln" > </h2>
   </div>
  	<div id="middleonePan">
  	  <ul class="block">
	  	<li><a href="../compose/compose.php">New <br />
  	    Meeting</a></li>
	  </ul>
	  <p class="boldtext">Organise a new meeting</p>
	  <p class="dotline"><img src="images/blank.gif" alt="" /></p>
	  <p>You have an idea for a new meeting. Get it signed by others.</p>
	
	  <p class="more"><a href="#">more</a></p>
  	</div>
	
    <div id="middletwoPan">
		<ul class="block">
			<li><a href="../inbox/inbox.php">Your<br />
				Actions</a></li>
		</ul>
		<p class="boldtext">What is in for you?</p>
	  <p class="dotline"><img src="images/blank.gif" alt="" /></p>
	  <p>Here you can read all the pages which have been addressed to you.</p>
	  
	  <p class="more"><a href="#">more</a></p>
	</div>
   
    <div id="middlethreePan">
		<ul class="block">
			<li><a href="../../chat/experts.php">Ask the<br />
  			Experts</a></li>
		</ul>
		<p class="boldtext">Have a doubt?</p>
	  <p class="dotline"><img src="images/blank.gif" alt="" /></p>
	  <p>You might be unsure on some of the factors and you might want in a suggestion.</p>
	  
	  <p class="more"><a href="#">more</a></p>
	</div>
   
     <div id="middlefourPan">
		<ul class="block">
			<li><a href="../Archives/results.php">Archive</a></li>
		</ul>
		<p class="boldtext">The Department's past!</p>
	  <p class="dotline"><img src="images/blank.gif" alt="" /></p>
	  <p>You are unsure whether your idea has been discussed earlier? Get along,</p>
	  
	  <p class="more"><a href="#">more</a></p>
	</div>
  </div>
</div>
    
    </body>
</html>
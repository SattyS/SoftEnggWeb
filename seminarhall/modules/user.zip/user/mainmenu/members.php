<html>
	<head>
    	<title>
        	Members Area
        </title>        
    </head>
    <body>
    
    <?php
	
	include("../../accounts/logclass.php");
	$obj = new Logclass;
	
	$result = $obj -> isLoggedIn();
	
	if( $result )
	{		
		include("pageone.php");
	}
	else
	{
		echo "Please login <a href='index.php'>here</a>";
	}
	
	?>
    </body>
</html>